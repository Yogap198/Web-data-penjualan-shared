# Aplikasi Penjualan Sederhana

Website untuk mencatat penjualan, pengeluaran, stok, dan laporan bulanan menggunakan Firebase.

## Fitur
- Login via Firebase
- Input data realtime ke Firestore
- Laporan otomatis
- Tampilan gelap & responsif

## Deploy
- Upload semua file ke GitHub
- Hubungkan dengan Netlify
